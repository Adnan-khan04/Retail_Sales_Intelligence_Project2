from fastapi import FastAPI, HTTPException
from src.retail_ai.data import default_data_path, load_transactions
from src.retail_ai.analytics import sales_summary, daily_sales

app = FastAPI(title="Retail AI Sales Intelligence API", version="0.1.0")


def get_data():
    path = default_data_path()
    if not path.exists():
        raise HTTPException(status_code=503, detail="Dataset not found. Run `python generate_data.py` first.")
    try:
        return load_transactions(path)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Could not load dataset: {exc}") from exc


@app.get("/health")
def health():
    return {"status": "ok", "service": "retail-ai-sales-intelligence"}


@app.get("/sales/summary")
def get_sales_summary():
    return sales_summary(get_data())


@app.get("/sales/daily")
def get_daily_sales(limit: int = 90):
    if limit < 1 or limit > 730:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 730")
    df = daily_sales(get_data()).tail(limit)
    return {"data": df.assign(order_date=df["order_date"].dt.strftime("%Y-%m-%d")).to_dict(orient="records")}


@app.get("/forecast/demand")
def demand_forecast(product_id: str | None = None, horizon_days: int = 30):
    if horizon_days < 1 or horizon_days > 90:
        raise HTTPException(status_code=400, detail="horizon_days must be between 1 and 90")
    # Baseline placeholder: replace with trained, backtested forecasting model in next step.
    df = get_data()
    if product_id:
        df = df[df["product_id"] == product_id]
    if df.empty:
        raise HTTPException(status_code=404, detail="No matching product data found")
    daily = df.assign(day=df["order_date"].dt.floor("D")).groupby("day")["quantity"].sum().sort_index()
    baseline = float(daily.tail(28).mean()) if not daily.empty else 0.0
    return {
        "product_id": product_id,
        "horizon_days": horizon_days,
        "method": "28-day average baseline (not a validated ML forecast)",
        "forecast_daily_units": round(baseline, 2),
        "forecast_total_units": round(baseline * horizon_days, 2),
    }
