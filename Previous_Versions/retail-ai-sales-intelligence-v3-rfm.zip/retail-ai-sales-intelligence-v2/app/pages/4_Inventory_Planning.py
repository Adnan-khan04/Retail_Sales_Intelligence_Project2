import streamlit as st
st.set_page_config(page_title="Inventory Planning", page_icon="📦", layout="wide")
st.title("📦 Inventory Planning")
st.info("Planned: forecast-led reorder points, safety stock, lead-time assumptions, and stockout/overstock alerts.")
