import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import streamlit as st
from src.retail_ai.data import default_data_path, load_transactions

st.set_page_config(page_title="Demand Forecasting", page_icon="🔮", layout="wide")
st.title("🔮 Demand Forecasting")
st.info("Next build step: lag/seasonal features, chronological backtesting, forecast intervals, and accuracy metrics.")
if not default_data_path().exists():
    st.warning("Run `python generate_data.py` first.")
else:
    df = load_transactions(default_data_path())
    products = sorted(df["product_id"].unique())
    product = st.selectbox("Product", products)
    horizon = st.slider("Forecast horizon (days)", 7, 90, 30)
    daily = df[df["product_id"] == product].assign(day=lambda x: x["order_date"].dt.floor("D")).groupby("day")["quantity"].sum().sort_index()
    baseline = float(daily.tail(28).mean())
    st.metric("Baseline daily units", f"{baseline:.2f}")
    st.metric(f"Baseline units over {horizon} days", f"{baseline * horizon:.1f}")
    st.caption("This is a simple baseline, not a validated prediction. Sparse sales days are not yet filled with zeros.")
