# Retail AI Sales Intelligence

A starter project for retail sales analytics, demand forecasting, churn risk, customer segmentation, pricing insights, and inventory planning.

## Features in this starter
- Synthetic retail transaction data generator
- CSV upload with basic schema validation
- Streamlit dashboard with sales overview and navigation
- FastAPI endpoints for health, sales summary, and forecast placeholder
- Modular `src/retail_ai` package for analytics/model code

## Requirements
- Python 3.11+ recommended
- Pandas 3.x

## Setup (Windows PowerShell)
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python generate_data.py
```

## Run the dashboard
```powershell
streamlit run app/Home.py
```

## Run the API (in another terminal)
```powershell
uvicorn api.main:app --reload
```
Open `http://127.0.0.1:8000/docs` for interactive API documentation.

## CSV schema
Required columns: `order_id`, `order_date`, `customer_id`, `product_id`, `category`, `quantity`, `unit_price`, `unit_cost`, `region`, `inventory_on_hand`.

Each row represents a product line in an order. Revenue is calculated as `quantity * unit_price`.

## Important modeling note
The initial forecast endpoint is deliberately a baseline placeholder. We should add chronological train/test backtesting before presenting forecasts as reliable. Churn scores should likewise be treated as heuristic until trained and validated on labeled repeat-purchase outcomes.
