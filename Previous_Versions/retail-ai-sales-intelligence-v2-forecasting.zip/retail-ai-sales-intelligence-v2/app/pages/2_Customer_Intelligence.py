import streamlit as st
st.set_page_config(page_title="Customer Intelligence", page_icon="👥", layout="wide")
st.title("👥 Customer Intelligence")
st.info("Planned: RFM features, customer segments, churn-risk indicators, and explanations for each score.")
st.markdown("**Modeling principle:** churn risk will be labeled as a probability only after we define an outcome window and validate the model on a time-based holdout.")
